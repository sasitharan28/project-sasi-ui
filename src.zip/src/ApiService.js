import axios from 'axios';

const USER_API_BASE_URL = 'http://localhost:8080/api';

class ApiService {

    //fetchUsers() {
    //    return axios.get(USER_API_BASE_URL);
    //}

    //fetchUserById(userId) {
    //    return axios.get(USER_API_BASE_URL + '?id=' + userId);
    //}

    //deleteUser(userId) {
    //    return axios.delete(USER_API_BASE_URL + '/' + userId);
    //}

    //addUser(user) {
    //    return axios.post(""+USER_API_BASE_URL, user);
    //}

    //editUser(user) {
    //    return axios.put(USER_API_BASE_URL + '/' + user.id, user);
    //}




    // fetchUsers() {
    //     return axios.get(USER_API_BASE_URL+'/user');
    // }
    //
    // editUser(user) {
    //     return axios.put(USER_API_BASE_URL + '/user' + user.id, user);
    // }
    //
    // deleteUser(userId) {
    //     return axios.delete(USER_API_BASE_URL + '/user/' + userId);
    // }

    viewUserById(userId){
        return axios.get(USER_API_BASE_URL + '/auth/user/' + userId);
    }




    getAllProducts(){
      return axios.get(USER_API_BASE_URL + '/products');
    }

    getProductById(productId){
        return axios.get(USER_API_BASE_URL + '/products/' + productId);
    }

    updateProduct(product){
        return axios.put(USER_API_BASE_URL + '/products/' + product.id, product);
    }

    addProduct(product){
        return axios.post(USER_API_BASE_URL,+'/products/'+ product);
    }

    deleteProduct(productId){
        return axios.delete(USER_API_BASE_URL + '/products/' + productId);
    }




    getAllOrders(){
        return axios.get(USER_API_BASE_URL+'/orders/');
    }
    getOrderById(orderId){
        return axios.get(USER_API_BASE_URL + '/order/' + orderId);
    }
    editOrder(order){
        return axios.put(USER_API_BASE_URL + '/order/' + order.id, order);
    }
    deleteOrderById(orderId){
        return axios.get(USER_API_BASE_URL + '/order/' + orderId);
    }
    addOrder(order) {
        return axios.post(USER_API_BASE_URL,+'/order/'+ order);
    }



    getAllShops(){
      return axios.get(USER_API_BASE_URL + '/shops');
    }
    createShop(shop){
        return axios.post(USER_API_BASE_URL + '/shops' , shop);
    }
    deleteShopById(shopId){
          return axios.delete(USER_API_BASE_URL + '/shops/'+shopId);
    }
    getShopById(shopId) {
        return axios.get(USER_API_BASE_URL + '/shops/' + shopId);
    }
    updateShop(shop){
        return axios.put(USER_API_BASE_URL + '/shops/' + shop.shopId, shop);
    }



    getFeedbackByProductId(productId){
        return axios.get(USER_API_BASE_URL + '/feedback?productId='+productId);
    }
    countFeedbackByProductId(productId){
        return axios.get(USER_API_BASE_URL + '/feedback?pro='+productId);
    }


}

export default new ApiService();
