import React, { Component } from 'react'
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Button from '@material-ui/core/Button';
import CreateIcon from '@material-ui/icons/Create';
import DeleteIcon from '@material-ui/icons/Delete';
import Typography from '@material-ui/core/Typography';
import Paper from '@material-ui/core/Typography';
import Box from '@material-ui/core/Typography';


import ApiService from "../../ApiService";


import AddBox from '@material-ui/icons/AddBox';
import AccountBox from '@material-ui/icons/AccountBox';
import Close from '@material-ui/icons/Close';




const style ={
    display: 'flex',
    justifyContent: 'center'
}

class OrderDetails extends Component {

    constructor(props) {
        super(props)
        this.state = {
            orders: [],
            message: null,
            visible:'none',
            buyProductDetails:[],
        }
    }

    componentDidMount() {
        this.reloadOrderList();
    }

    // reloadOrderList = () => {
    //     ApiService.getAllOrders()
    //         .then((res) => {
    //             this.setState({orders: res.data})
    //         });
    // }

    reloadOrderList = () =>{
      ApiService.getAllOrders()
          .then((res) => {
            let item=res.data;
              {
                item.map(item =>(
                  ApiService.viewUserById(item.userId)
                      .then((res) => {
                          let userDetails = res.data;
                          this.setState(prevState => ({
                            buyProductDetails:item.buyProductDetails,
                            // orders: [...prevState.orders, {
                            //   "orderId":item.orderId,
                            //   "shopId":item.shopId,
                            //   "userId":item.userId,
                            //
                            //   "totalPrice":item.totalPrice,
                            //   "orderDateTime":item.orderDateTime,
                            //   "userName":userDetails.userName,
                            //   "email":userDetails.email,
                            //   "address":userDetails.address,
                            // }]
                          }))
                          {this.state.buyProductDetails.map(row => (

                              // <ul>
                              //   <li>buyProductDetails :- {row.buyProductId}</li>
                              //   <li>quantity :- {row.quantity}</li>
                              //   <li>price :- {row.price}</li>
                              // </ul>
                              this.setState(prevState => ({
                                orders: [...prevState.orders, {
                                  "orderId":item.orderId,
                                  "shopId":item.shopId,
                                  "userId":item.userId,
                                  "buyProductId":row.buyProductId,
                                  "quantity":row.quantity,
                                  "price":row.price,
                                  "totalPrice":item.totalPrice,
                                  "orderDateTime":item.orderDateTime,
                                  "userName":userDetails.userName,
                                  "email":userDetails.email,
                                  "address":userDetails.address,
                                }]
                              }))
                          ))}
                      })
                ))
              }
          });

    }





    deleteOrder = (orderId) => {
        this.setState({
            deleteOrderId:`${orderId}`,
            visible:'block',
        })
    }


    handlecoverHide = (e) =>{
      this.setState({
        visible:'none',
      })
    }

    handleConformDelete = () =>{

        ApiService.deleteOrderById(this.state.deleteOrderId)
           .then(res => {
               this.setState({message : 'Order deleted successfully.'});
               //this.setState({Orders: this.state.Orders.filter(order => order.id !== this.state.deleteOrderId)});
               setTimeout(() => {
                   this.props.history.push('/orderDetails');
                   window.location.reload();
               },500);
           })
           this.setState({message : 'Order deleted successfully.'});
           //this.setState({Orders: this.state.Orders.filter(order => order.id !== this.state.deleteOrderId)});
           setTimeout(() => {
               this.props.history.push('/orderDetails');
               window.location.reload();
           },500);
    }

    editOrder = (id) => {
        window.localStorage.setItem("editOrderId", id);
        this.props.history.push('/editOrder');
    }

    addOrder = () => {
        window.localStorage.removeItem("orderId");
        this.props.history.push('/addOrder');
    }

    render() {

      const orders= this.state.orders

        return (
            <div style={{width:'90%',margin:'auto', backgroundColor:'white' , marginTop:'50px',}}>
                <Typography variant="h4" style={style}>Order Details</Typography>
                <Button variant="contained" style={{backgroundColor:'#03a9f4',color:'white',float:'right',marginRight:'30px',fontWeight:'bold'}} onClick={() => this.addOrder()}><AddBox style={{marginRight:'5px'}}/>
                    Add Order
                </Button>

              

                <Table>
                    <TableHead>
                        <TableRow>
                            <TableCell>Id</TableCell>
                            <TableCell align="left">UserName</TableCell>
                            <TableCell align="left">Product Id</TableCell>
                            <TableCell align="left">Time</TableCell>
                            <TableCell align="left">Date</TableCell>
                            <TableCell align="left">Price</TableCell>
                            <TableCell align="left">Quantity</TableCell>
                            <TableCell align="left">Email</TableCell>
                            <TableCell align="left">Address</TableCell>


                        </TableRow>
                    </TableHead>
                    <TableBody>
                        {orders.map(row => (
                            <TableRow key={row.orderId}>
                                <TableCell component="th" scope="row">
                                    {row.orderId}
                                </TableCell>
                                <TableCell align="left">{row.userName}</TableCell>
                                <TableCell align="left">{row.buyProductId}</TableCell>
                                <TableCell align="left">{row.time}</TableCell>
                                <TableCell align="left">{row.orderDateTime}</TableCell>
                                <TableCell align="left">{row.price}</TableCell>
                                <TableCell align="left">{row.quantity}</TableCell>
                                <TableCell align="left">{row.email}</TableCell>
                                <TableCell align="left">{row.address}</TableCell>
                                <TableCell align="left" onClick={() => this.editOrder(row.orderId)}><Button><CreateIcon /></Button></TableCell>
                                <TableCell align="left" onClick={() => this.deleteOrder(row.orderId)}><Button><DeleteIcon /></Button></TableCell>

                            </TableRow>
                        ))}
                    </TableBody>
                </Table>

                <Box style={{display:this.state.visible,width:"100%",height:"100%",position:"fixed",top:"0px",left:"0px",backgroundColor:"black",opacity:"0.8",zIndex:"3"}}  onClick={() => this.handlecoverHide()}></Box>
                <Paper elevation="3" style={{display:this.state.visible,position:"fixed",top:"200px",left: `${window.innerWidth/2-275}px`,backgroundColor:"white",zIndex:"4",width: "550px",
                height: "200px" }} >
                    {!this.state.message&&(
                      <Box>
                        <Typography variant='h4' style={{textAlign:"center",marginTop:"20px"}}>Are you sure delete this Order?</Typography>
                        <Button  onClick={() => this.handlecoverHide()}   style={{color: "white",fontWeight: "bold",backgroundColor: "#03a9f4",marginTop: "50px",float:"left",marginLeft:"100px"}}><Close style={{marginRight:"5px"}}/>Cancel</Button>
                        <Button id="deleteShopConformDelete" onClick={() => this.handleConformDelete()}style={{color: "white",fontWeight: "bold",backgroundColor: "#03a9f4",marginRight: "100px",marginTop: "50px",float:"right",marginright:"100px"}}><DeleteIcon  style={{marginRight:'5px'}}/>Delete</Button>
                      </Box>
                    )}
                    <Typography variant='h4' style={{textAlign:'center',marginTop:'30px'}}>{this.state.message}</Typography>
                </Paper>

            </div>
        );
    }

}

export default OrderDetails;
