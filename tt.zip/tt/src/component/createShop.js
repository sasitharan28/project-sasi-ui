import React, { Component } from 'react'
import { Card, CardContent, Grid, FormControl, TextField, Input, FormHelperText, OutlinedInput ,Select } from '@material-ui/core';
import { Paper, Typography, AppBar, Toolbar, Button, IconButton ,Divider,Box } from "@material-ui/core";

import { ValidatorForm, TextValidator} from 'react-material-ui-form-validator';


import { makeStyles } from '@material-ui/core/styles';
import InputLabel from '@material-ui/core/InputLabel';

import ApiService from "../ApiService";
import AddImg from './images/add.png';




import AddBox from '@material-ui/icons/AddBox';




import './css/editOrder.css';

const style ={
  float:'right',
  marginRight:'50px',
  marginTop:'30px',
}

class CreateShop extends Component {

    constructor(props){
        super(props);
        this.state ={
          shopName:'',
          phone:'',
          address:'',
          description:'',

          message:'',

          file1: '',
          imagePreviewUrl1: '',
        }
        // this.saveUser = this.saveUser.bind(this);
        // this.loadUser = this.loadUser.bind(this);
    }



    onChange = (e) =>{
        this.setState({ [e.target.name]: e.target.value });
    }
    createShop = (e) => {
        e.preventDefault();
        let shop = {
          ownerId:localStorage.getItem("username"),
          shopName: this.state.shopName,
          description:this.state.description,
          telephone: this.state.phone,
          address: this.state.address,
          shopLogo:"",
        };
        ApiService.createShop(shop)
            .then(res => {
                this.setState({message : 'Shop create successfully.'});
                setTimeout(() => {
                    this.props.history.push('/createShop');
                    window.location.reload();
                },500);
            });

    }

    _handleImage1Change1(e) {
      e.preventDefault();

      let reader1 = new FileReader();
      let file1 = e.target.files[0];

      reader1.onloadend = () => {
        this.setState({
          file1: file1,
          imagePreviewUrl1: reader1.result
        });
      }

      reader1.readAsDataURL(file1)
    }


    render() {
        let {imagePreviewUrl1} = this.state;
        return (
            <div>
            {this.state.message&&(
              <div>
                  <div id="shopCreateAlertMsgCoverDiv" style={{width: '100%',height:'100%',position: 'fixed',top:'0px',left: '0px',backgroundColor: 'black',opacity: '0.9',zIndex: '2'}}>

                  </div>
                  <Paper elevation="5" id="shopCreateAlertMsgCoverDivPaper" style={{position: 'fixed',width:'500px',height:'150px',backgroundColor:'white',margin:'auto',top:'200px',zIndex: '3',left:`${window.innerWidth/2-250}px`,}} >
                    <Typography variant="h4" style={{textAlign:'center',position:'relative',top:'50px'}}>{this.state.message}</Typography>
                  </Paper>
              </div>
            )}
            <Paper className='shopCreatePaper' style={{height:'700px',width:'90%',margin:'auto'}} elevation={1}>
              <Typography id="profileHeading">Create Shop</Typography>

              <ValidatorForm onSubmit={this.createShop} >
                <Grid container id="profileGrid">


                <Grid item xs={12} sm={12} md={6}>
                  <Paper style={{height:'150px',width:'90%',margin:'auto',marginTop:'15px',}} elevation={3}>
                      <Typography variant="h6" id="userNameDivTitle">Shop Logo</Typography>
                      <div style={{float: 'left',marginTop: '10px',width: '100px',height: '100px',border: '1px solid black',marginLeft: '40px',}}>
                          <input className="fileInput1"
                            type="file"
                            accept="image/*"
                            onChange={(e)=>this._handleImage1Change1(e)}
                           />

                           {!imagePreviewUrl1&&(
                              <img src={AddImg} className="addItemImg1" />
                            )}
                              <img src={imagePreviewUrl1} className="addItemImg1" />

                      </div>
                  </Paper>
                </Grid>




                      <Grid item xs={12} sm={12} md={6}>
                        <Paper id="userNameDiv"  elevation={3}>
                            <Typography variant="h6" id="userNameDivTitle">Shop Name</Typography>

                            <TextValidator

                                variant="outlined"
                                label="Shop Name"
                                onChange={this.onChange}
                                name="shopName"
                                value={this.state.shopName}
                                Id="firstNameIp"
                                validators={['required']}
                                errorMessages={['this field is required']}
                            />

                        </Paper>
                      </Grid>



                      <Grid item xs={12} sm={12} md={6}>
                        <Paper id="phoneDiv" elevation={3}>
                            <Box id="phonebox">
                                <Typography variant="h6" id="lastNameDivTitle">Phone Number</Typography>

                                    <TextValidator
                                        variant="outlined"
                                        label="Shop Name"
                                        onChange={this.onChange}
                                        name="phone"
                                        value={this.state.phone}
                                        Id="firstNameIp"
                                        type="Number"
                                        validators={['required']}
                                        errorMessages={['this field is required']}
                                    />

                            </Box>
                        </Paper>
                      </Grid>



                      <Grid item xs={12} sm={12} md={6}>
                        <Paper id="addressDiv" elevation={3}>
                            <Box id="addressbox">
                                <Typography variant="h6" id="lastNameDivTitle">Address</Typography>

                                    <TextValidator
                                        variant="outlined"
                                        label="Address"
                                        onChange={this.onChange}
                                        name="address"
                                        value={this.state.address}
                                        Id="firstNameIp"
                                        validators={['required']}
                                        errorMessages={['this field is required']}
                                    />
                            </Box>
                        </Paper>
                      </Grid>

                      <Grid item xs={12} sm={12} md={6}>
                        <Paper id="descriptionDiv" elevation={3} style={{height:"170px",width:"90%",margin:"auto",marginTop:"10px"}}>
                            <Box id="descriptionbox">
                                <Typography variant="h6" id="lastNameDivTitle">Description</Typography>
                                    <textarea value={this.state.description} name="description" placeholder="Description....." onChange={this.onChange} style={{width:"90%",height:"100px",display:"flex",margin:"auto",marginTop:"10px",resize:"none"}}>

                                    </textarea>

                            </Box>
                        </Paper>
                      </Grid>

                      <Grid item xs={12} sm={12} >
                          <Box style={style}>
                            <Button type="submit" style={{backgroundColor:'white',fontWeight:'bold',backgroundColor:'#03a9f4',color:'white'}}> <AddBox style={{marginRight:'5px'}}/> Create Shop</Button>
                          </Box>
                      </Grid>
                </Grid>
                </ValidatorForm>

            </Paper>
            </div>
        );
    }
}

export default CreateShop;
